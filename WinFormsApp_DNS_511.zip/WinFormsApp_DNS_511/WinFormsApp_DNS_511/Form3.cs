﻿using System;
using System.Net;
using System.Windows.Forms;

namespace WinFormsApp_DNS_511
{
    public partial class Form3 : Form
    {
        private readonly string[] hosts = new string[]
        {
            "CERN.ch",
            "nasa.gov",
            "mit.edu",
            "unimelb.edu.au",
            "ox.ac.uk",
            "stanford.edu"
        };

        // Переменные для хранения данных выбранных хостов
        private IpInfo host1Info = null;
        private IpInfo host2Info = null;

        public Form3()
        {
            InitializeComponent();

            // Заполняем список хостов
            listBoxHosts.Items.AddRange(hosts);

            // Привязка кнопок и событий
            listBoxHosts.SelectedIndexChanged += ListBoxHosts_SelectedIndexChanged;
            btnClear.Click += BtnClear_Click;
            btnCalculate.Click += BtnCalculate_Click;
        }

        private async void ListBoxHosts_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxHosts.SelectedItem == null) return;

            // Если обе ячейки уже заполнены, игнорируем клик пока не нажмут Clear
            if (host1Info != null && host2Info != null) return;

            string selectedHost = listBoxHosts.SelectedItem.ToString();
            string ip = await GetIpAddressAsync(selectedHost);

            if (string.IsNullOrEmpty(ip))
            {
                MessageBox.Show("Не удалось определить IP для " + selectedHost);
                return;
            }

            // Получаем гео-данные[cite: 17]
            IpInfo geoInfo = await LocationHelper.GetIpInfoAsync(ip);

            // Заполняем первую ячейку, если она пуста[cite: 17]
            if (host1Info == null)
            {
                host1Info = geoInfo;
                lblHost1Name.Text = selectedHost;
                txtHost1Ip.Text = ip;
                lblHost1Geo.Text = $"lat: {geoInfo.Lat},\nlong: {geoInfo.Lon}";
            }
            // Заполняем вторую ячейку, если первая занята[cite: 17]
            else if (host2Info == null)
            {
                host2Info = geoInfo;
                lblHost2Name.Text = selectedHost;
                txtHost2Ip.Text = ip;
                lblHost2Geo.Text = $"lat: {geoInfo.Lat},\nlong: {geoInfo.Lon}";
            }

            listBoxHosts.ClearSelected();
        }

        private void BtnCalculate_Click(object sender, EventArgs e)
        {
            // Вычисляем расстояние только если выбраны оба хоста[cite: 17]
            if (host1Info != null && host2Info != null)
            {
                double distance = GeoMath.CalculateDistance(host1Info.Lat, host1Info.Lon, host2Info.Lat, host2Info.Lon);
                lblDistance.Text = $"Distance = {Math.Round(distance)}km";
            }
            else
            {
                MessageBox.Show("Будь ласка, оберіть два хости зі списку.");
            }
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            // Очищаем поля[cite: 17]
            host1Info = null;
            host2Info = null;

            lblHost1Name.Text = "host1";
            txtHost1Ip.Text = "";
            lblHost1Geo.Text = "lat: 0, long: 0";

            lblHost2Name.Text = "host2";
            txtHost2Ip.Text = "";
            lblHost2Geo.Text = "lat: 0, long: 0";

            lblDistance.Text = "Distance = 0km";
        }

        // Быстрый метод для получения IP вместо долгого Ping Tracing
        private async System.Threading.Tasks.Task<string> GetIpAddressAsync(string hostname)
        {
            try
            {
                IPAddress[] addresses = await Dns.GetHostAddressesAsync(hostname);
                if (addresses.Length > 0)
                {
                    return addresses[0].ToString();
                }
            }
            catch { }

            return string.Empty;
        }
    }
}