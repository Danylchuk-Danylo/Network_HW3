﻿namespace WinFormsApp_DNS_511
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listBoxHosts = new ListBox();
            lblHost1Name = new Label();
            txtHost1Ip = new TextBox();
            txtHost2Ip = new TextBox();
            lblHost2Name = new Label();
            lblHost1Geo = new Label();
            lblHost2Geo = new Label();
            lblDistance = new Label();
            btnClear = new Button();
            btnCalculate = new Button();
            SuspendLayout();
            // 
            // listBoxHosts
            // 
            listBoxHosts.FormattingEnabled = true;
            listBoxHosts.Location = new Point(36, 32);
            listBoxHosts.Name = "listBoxHosts";
            listBoxHosts.Size = new Size(238, 548);
            listBoxHosts.TabIndex = 0;
            // 
            // lblHost1Name
            // 
            lblHost1Name.AutoSize = true;
            lblHost1Name.Location = new Point(338, 23);
            lblHost1Name.Name = "lblHost1Name";
            lblHost1Name.Size = new Size(73, 32);
            lblHost1Name.TabIndex = 1;
            lblHost1Name.Text = "host1";
            // 
            // txtHost1Ip
            // 
            txtHost1Ip.Location = new Point(338, 68);
            txtHost1Ip.Name = "txtHost1Ip";
            txtHost1Ip.ReadOnly = true;
            txtHost1Ip.Size = new Size(200, 39);
            txtHost1Ip.TabIndex = 2;
            // 
            // txtHost2Ip
            // 
            txtHost2Ip.Location = new Point(338, 195);
            txtHost2Ip.Name = "txtHost2Ip";
            txtHost2Ip.ReadOnly = true;
            txtHost2Ip.Size = new Size(200, 39);
            txtHost2Ip.TabIndex = 3;
            // 
            // lblHost2Name
            // 
            lblHost2Name.AutoSize = true;
            lblHost2Name.Location = new Point(338, 146);
            lblHost2Name.Name = "lblHost2Name";
            lblHost2Name.Size = new Size(73, 32);
            lblHost2Name.TabIndex = 4;
            lblHost2Name.Text = "host2";
            // 
            // lblHost1Geo
            // 
            lblHost1Geo.AutoSize = true;
            lblHost1Geo.Location = new Point(596, 68);
            lblHost1Geo.Name = "lblHost1Geo";
            lblHost1Geo.Size = new Size(150, 32);
            lblHost1Geo.TabIndex = 5;
            lblHost1Geo.Text = "lat: 0, long: 0";
            // 
            // lblHost2Geo
            // 
            lblHost2Geo.AutoSize = true;
            lblHost2Geo.Location = new Point(596, 195);
            lblHost2Geo.Name = "lblHost2Geo";
            lblHost2Geo.Size = new Size(150, 32);
            lblHost2Geo.TabIndex = 6;
            lblHost2Geo.Text = "lat: 0, long: 0";
            // 
            // lblDistance
            // 
            lblDistance.AutoSize = true;
            lblDistance.Location = new Point(338, 328);
            lblDistance.Name = "lblDistance";
            lblDistance.Size = new Size(181, 32);
            lblDistance.TabIndex = 7;
            lblDistance.Text = "Distance = 0km";
            // 
            // btnClear
            // 
            btnClear.Location = new Point(355, 455);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(195, 92);
            btnClear.TabIndex = 8;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            // 
            // btnCalculate
            // 
            btnCalculate.Location = new Point(625, 455);
            btnCalculate.Name = "btnCalculate";
            btnCalculate.Size = new Size(193, 92);
            btnCalculate.TabIndex = 9;
            btnCalculate.Text = "Calculate";
            btnCalculate.UseVisualStyleBackColor = true;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(873, 605);
            Controls.Add(btnCalculate);
            Controls.Add(btnClear);
            Controls.Add(lblDistance);
            Controls.Add(lblHost2Geo);
            Controls.Add(lblHost1Geo);
            Controls.Add(lblHost2Name);
            Controls.Add(txtHost2Ip);
            Controls.Add(txtHost1Ip);
            Controls.Add(lblHost1Name);
            Controls.Add(listBoxHosts);
            Name = "Form3";
            Text = "Form3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox listBoxHosts;
        private Label lblHost1Name;
        private TextBox txtHost1Ip;
        private TextBox txtHost2Ip;
        private Label lblHost2Name;
        private Label lblHost1Geo;
        private Label lblHost2Geo;
        private Label lblDistance;
        private Button btnClear;
        private Button btnCalculate;
    }
}