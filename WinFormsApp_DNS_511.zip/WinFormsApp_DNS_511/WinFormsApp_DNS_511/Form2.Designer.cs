﻿namespace WinFormsApp_DNS_511
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonGetIpInfo = new Button();
            textBoxOutput = new TextBox();
            buttonGetLastIp = new Button();
            listBoxAddresses = new ListBox();
            buttonGetBankInfo = new Button();
            listBoxRates = new ListBox();
            SuspendLayout();
            // 
            // buttonGetIpInfo
            // 
            buttonGetIpInfo.Location = new Point(12, 12);
            buttonGetIpInfo.Name = "buttonGetIpInfo";
            buttonGetIpInfo.Size = new Size(94, 29);
            buttonGetIpInfo.TabIndex = 0;
            buttonGetIpInfo.Text = "Get IP info";
            buttonGetIpInfo.UseVisualStyleBackColor = true;
            buttonGetIpInfo.Click += buttonGetIpInfo_Click;
            // 
            // textBoxOutput
            // 
            textBoxOutput.Location = new Point(12, 317);
            textBoxOutput.Multiline = true;
            textBoxOutput.Name = "textBoxOutput";
            textBoxOutput.Size = new Size(776, 121);
            textBoxOutput.TabIndex = 1;
            // 
            // buttonGetLastIp
            // 
            buttonGetLastIp.Location = new Point(124, 12);
            buttonGetLastIp.Name = "buttonGetLastIp";
            buttonGetLastIp.Size = new Size(94, 29);
            buttonGetLastIp.TabIndex = 2;
            buttonGetLastIp.Text = "Get last Ip";
            buttonGetLastIp.UseVisualStyleBackColor = true;
            // 
            // listBoxAddresses
            // 
            listBoxAddresses.FormattingEnabled = true;
            listBoxAddresses.Location = new Point(124, 58);
            listBoxAddresses.Name = "listBoxAddresses";
            listBoxAddresses.Size = new Size(150, 244);
            listBoxAddresses.TabIndex = 3;
            listBoxAddresses.SelectedIndexChanged += listBoxAddresses_SelectedIndexChanged;
            // 
            // buttonGetBankInfo
            // 
            buttonGetBankInfo.Location = new Point(549, 12);
            buttonGetBankInfo.Name = "buttonGetBankInfo";
            buttonGetBankInfo.Size = new Size(239, 29);
            buttonGetBankInfo.TabIndex = 4;
            buttonGetBankInfo.Text = "Get bank info";
            buttonGetBankInfo.UseVisualStyleBackColor = true;
            buttonGetBankInfo.Click += buttonGetBankInfo_Click;
            // 
            // listBoxRates
            // 
            listBoxRates.FormattingEnabled = true;
            listBoxRates.Location = new Point(358, 47);
            listBoxRates.Name = "listBoxRates";
            listBoxRates.Size = new Size(430, 264);
            listBoxRates.TabIndex = 5;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(listBoxRates);
            Controls.Add(buttonGetBankInfo);
            Controls.Add(listBoxAddresses);
            Controls.Add(buttonGetLastIp);
            Controls.Add(textBoxOutput);
            Controls.Add(buttonGetIpInfo);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonGetIpInfo;
        private TextBox textBoxOutput;
        private Button buttonGetLastIp;
        private ListBox listBoxAddresses;
        private Button buttonGetBankInfo;
        private ListBox listBoxRates;
    }
}