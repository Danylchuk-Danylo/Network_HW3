﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp_DNS_511
{
    public partial class Form2 : Form
    {
        private static readonly string[] hosts = new string[]
        {
            "CERN.ch",
            "nasa.gov",
            "mit.edu",
            "unimelb.edu.au"
        };

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            LoadListBoxAddresses();
        }

        private void LoadListBoxAddresses()
        {
            listBoxAddresses.Items.AddRange(hosts);
        }

        private async void listBoxAddresses_SelectedIndexChanged(object sender, EventArgs e)
        {
            string address = listBoxAddresses.SelectedItem?.ToString() ?? string.Empty;
            if (!string.IsNullOrEmpty(address))
            {
                address = UrlHelper.FixUrlProtocol(address);

                // Запускаємо трасировку в окремому потоці, щоб форма не зависала
                string targetIp = await Task.Run(() => GetLastIp(UrlHelper.ExtractHost(address)));

                if (!string.IsNullOrEmpty(targetIp))
                {
                    IpInfo ipInfoTest = await GetIpInfoAsync(targetIp);

                    // Виводимо результат, якщо є поле textBoxOutput
                    if (textBoxOutput != null)
                    {
                        textBoxOutput.Text = ipInfoTest.SourceData;
                    }
                }
            }
        }

        private async void buttonGetIpInfo_Click(object sender, EventArgs e)
        {
            IpInfo ipInfoTest = await GetIpInfoAsync();
            ipInfoTest = await GetIpInfoAsync(ipInfoTest.Query);

            if (textBoxOutput != null)
            {
                textBoxOutput.Text = ipInfoTest.SourceData;
            }
        }

        private async Task<IpInfo> GetIpInfoAsync(string address = null)
        {
            return await LocationHelper.GetIpInfoAsync(address);
        }

        private string GetLastIp(string host)
        {
            int maxHops = 30;
            int timeout = 2500; // default TTL

            Debug.WriteLine("Tracing route started.");

            using var ping = new Ping();
            byte[] buffer = Encoding.UTF8.GetBytes("data");

            string lastIp = string.Empty;

            for (int ttl = 1; ttl < maxHops; ttl++)
            {
                PingOptions pingOptions = new PingOptions(ttl, true);
                try
                {
                    PingReply pingReply = ping.Send(host, timeout, buffer, pingOptions);

                    if (pingReply.Status == IPStatus.TimeExceeded)
                    {
                        Debug.WriteLine($"{ttl,2} | IP: {pingReply.Address,-15} | Time: {pingReply.RoundtripTime}ms");
                    }
                    else if (pingReply.Status == IPStatus.Success)
                    {
                        Debug.WriteLine($"{ttl,2} | IP: {pingReply.Address,-15} | Reached! Final ping: {pingReply.RoundtripTime}ms");
                        lastIp = pingReply.Address.ToString();
                        break;
                    }
                    else if (pingReply.Status == IPStatus.TimedOut)
                    {
                        Debug.WriteLine($"{ttl,2} | IP: * * * | Request timed out");
                    }
                    else
                    {
                        Debug.WriteLine($"{ttl,2} | Error: {pingReply.Status}");
                    }
                }
                catch
                {
                    break;
                }
            }

            Debug.WriteLine("Tracing route completed.");

            return lastIp;
        }

        private async void buttonGetBankInfo_Click(object sender, EventArgs e)
        {
            List<RateInfo> rates = await BankHelper.GetBankInfoAsync();

            if (rates != null)
            {
                rates = rates.OrderByDescending(r => r.Rate).ToList();

                listBoxRates.Items.Clear();
                foreach (var item in rates)
                {
                    listBoxRates.Items.Add(item);
                }
            }
        }
    }
}
